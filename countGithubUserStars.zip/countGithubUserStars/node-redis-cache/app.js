// express will handle the routing for our API
// response-time is a middleware to return the response time for requests in a X-Response-Time header. We will be using this to inspect how much of a speed up redis actually provides
// redis is a redis client for NodeJs with a convenient API
// axios will be used to make HTTP requests to the GitHub API using promises


//1. dependencies
var app=require('express')();
var responseTime=require('response-time');
var axios= require('axios');
var redis=require('redis');


//2.redis client create & connect to local redis instance

var client=redis.createClient();

//if error, print in console

client.on('error', function(err){
 console.log("error"+err);
});


app.set('port',(process.env.PORT || 5000));

//settting response time middleware
app.use(responseTime());

//if person  visits /api/facebook, return stars that user'facebook' has on public repo

app.get('/api/:username', function(req, res){

    var username=req.params.username;

    //use redis to get total no. of stars associated

    client.get(username, function(error, result){
        if(result){
            res.send({'totalStars':result, "source": "redis cache"});
        }

        else{
            getUserRepo(username)
            .then(computeTotalStars)
            .then(function(totalStars){
                //store key-value i.e. username: stars in redis

                //and expiry of 1 min

                client.setex(username, 60, totalStars);

                //return result to user

                res.send({"totalStars":totalStars, "source":"gitHub Api"});
            }).catch(function(response){
                if(response.status==404){
                    res.send("git hub user not found, try qrk18 instead")
                }
                else
                {
                    res.send(response);
                }
            })
        }
    })

});


app.listen(app.get('port'), function(){
console.log('server lsitening on', app.get('port'));
});

//call github api to fetch info about user
function getUserRepo(user){
    var githubEndPoint='https://api.github.com/users/'+user + '/repos'+'?per_page=100';
    return axios.get(githubEndPoint);
}


//stars coutn

function computeTotalStars(repo){
    return repo.data.reduce(function(prev, curl){
        return prev +curl.stargazers_count
    },0)
}


